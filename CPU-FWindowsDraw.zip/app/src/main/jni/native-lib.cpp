#include <jni.h>
#include <android/native_window_jni.h>
#include <android/native_window.h>
#include <cstring>
#include <thread>
#include <atomic>
#include <cmath>

#define WINDOW_FORMAT_RGBA_8888 1

static int g_pattern = 0;
static bool g_running = false;
static ANativeWindow* g_window = nullptr;
static std::thread g_drawThread;

inline uint32_t rgba(uint8_t r, uint8_t g, uint8_t b, uint8_t a = 255) {
    return r | (g << 8) | (b << 16) | (a << 24);
}

void drawPattern(uint32_t* pixels, int stride, int width, int height, int pattern) {
    memset(pixels, 0, stride * height * 4);

    switch (pattern) {
        case 0: {
            int cx = width / 2, cy = height / 2, r = 80;
            for (int y = 0; y < height; ++y)
                for (int x = 0; x < width; ++x) {
                    int dx = x - cx, dy = y - cy;
                    if (dx * dx + dy * dy <= r * r)
                        pixels[y * stride + x] = rgba(255, 0, 0, 200);
                }
            break;
        }
        case 1: {
            int x0 = width / 2 - 100, y0 = height / 2 - 100;
            int x1 = width / 2 + 100, y1 = height / 2 + 100;
            for (int y = y0; y <= y1; ++y)
                for (int x = x0; x <= x1; ++x)
                    pixels[y * stride + x] = rgba(0, 255, 0, 200);
            break;
        }
    }
}

void drawLoop() {
    while (g_running) {
        ANativeWindow_Buffer buffer;
        if (ANativeWindow_lock(g_window, &buffer, nullptr) == 0) {
            uint32_t* pixels = static_cast<uint32_t*>(buffer.bits);
            drawPattern(pixels, buffer.stride, buffer.width, buffer.height, g_pattern);
            ANativeWindow_unlockAndPost(g_window);
        }
        std::this_thread::sleep_for(std::chrono::milliseconds(16));
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_cpu_FloatingService_nativeStartDrawing(JNIEnv* env, jobject) {
    g_window = ANativeWindow_fromSurface(env, env->CallObjectMethod(
        env->CallStaticObjectMethod(env->FindClass("android/view/Display"),
            env->GetMethodID(env->FindClass("android/view/Display"), "getWindow", "()Landroid/view/Surface;")),
        env->GetMethodID(env->FindClass("android/view/Surface"), "getSurface", "()Landroid/view/Surface;")));

    ANativeWindow_setBuffersGeometry(g_window, 600, 400, WINDOW_FORMAT_RGBA_8888);
    g_running = true;
    g_drawThread = std::thread(drawLoop);
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_cpu_FloatingService_nativeStopDrawing(JNIEnv*, jobject) {
    g_running = false;
    if (g_drawThread.joinable()) g_drawThread.join();
    if (g_window) {
        ANativeWindow_release(g_window);
        g_window = nullptr;
    }
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_cpu_FloatingService_nativeDrawPattern(JNIEnv*, jobject, jint pattern) {
    g_pattern = pattern;
}

