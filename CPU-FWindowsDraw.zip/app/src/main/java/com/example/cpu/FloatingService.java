package com.example.cpu;

import android.app.Service;
import android.content.Intent;
import android.graphics.PixelFormat;
import android.os.Build;
import android.os.IBinder;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;

public class FloatingService extends Service {
    private WindowManager windowManager;
    private View rootView;
    private WindowManager.LayoutParams rootParams;

    @Override
    public void onCreate() {
        super.onCreate();
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);

        rootView = LayoutInflater.from(this).inflate(R.layout.float_imgui, null);
        Button btnCircle = rootView.findViewById(R.id.btn_circle);
        Button btnRect = rootView.findViewById(R.id.btn_rect);

        btnCircle.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					nativeDrawPattern(0);
				}
			});

        btnRect.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {
					nativeDrawPattern(1);
				}
			});

        rootParams = new WindowManager.LayoutParams(
			WindowManager.LayoutParams.WRAP_CONTENT,
			WindowManager.LayoutParams.WRAP_CONTENT,
			Build.VERSION.SDK_INT >= Build.VERSION_CODES.O ?
			WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY :
			WindowManager.LayoutParams.TYPE_PHONE,
			WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
			WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
			PixelFormat.TRANSLUCENT);

        rootParams.gravity = Gravity.TOP | Gravity.LEFT;
        rootParams.x = 100;
        rootParams.y = 100;

        windowManager.addView(rootView, rootParams);

        nativeStartDrawing();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        if (rootView != null) {
            windowManager.removeView(rootView);
            rootView = null;
        }
        nativeStopDrawing();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    static {
        System.loadLibrary("native-lib");
    }

    private native void nativeStartDrawing();
    private native void nativeStopDrawing();
    private native void nativeDrawPattern(int pattern);
}

