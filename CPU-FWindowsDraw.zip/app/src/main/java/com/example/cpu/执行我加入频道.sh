#!/system/bin/sh

ENCODED_TG_URL="dGc6Ly9yZXNvbHZlP2RvbWFpbj1hYWRhaWxpJnBvc3Q9Ng=="

ENCODED_WEB_URL="aHR0cHM6Ly90Lm1lL2FhZGFpbGk="


TELEGRAM_URL=$(echo "$ENCODED_TG_URL" | base64 -d)
WEB_URL=$(echo "$ENCODED_WEB_URL" | base64 -d)

# 检查是否以 root 权限运行
if [ "$(id -u)" -ne 0 ]; then
    echo "未检测到 Root 权限。"
    echo "请您手动复制以下链接至浏览器或 Telegram 客户端打开："
    echo "$WEB_URL"
    echo "或尝试使用支持 Root 的方式运行本脚本。"
    exit 1
fi

# 使用 am start 打开 Telegram 
am start -a android.intent.action.VIEW -d "$TELEGRAM_URL" > /tmp/telegram_open.log 2>&1

# 判断是否执行成功
if [ $? -eq 0 ]; then
    echo "正在尝试打开 Telegram，请稍候..."
else
    echo "打开 Telegram 消息失败。请检查 /tmp/telegram_open.log 日志获取详细信息。"
    exit 1
fi